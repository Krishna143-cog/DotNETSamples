﻿using System.Web;
using System.Web.Mvc;

namespace Hands_ON_43_HTML_HELPERS
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
