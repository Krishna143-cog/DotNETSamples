﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Hands_On_Validations.Models;
namespace Hands_On_Validations.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Save(Account account)
        {
            ViewBag.account = account;
            return View("Success");
        }
    }
}