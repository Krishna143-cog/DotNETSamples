﻿using System.Web;
using System.Web.Mvc;

namespace Hands_On_CRUD_IN_MVC_WITHOUT_ENTITY_FRAMEWORK_45
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
