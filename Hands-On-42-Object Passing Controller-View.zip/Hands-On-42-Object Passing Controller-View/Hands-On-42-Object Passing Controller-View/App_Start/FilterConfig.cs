﻿using System.Web;
using System.Web.Mvc;

namespace Hands_On_42_Object_Passing_Controller_View
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
