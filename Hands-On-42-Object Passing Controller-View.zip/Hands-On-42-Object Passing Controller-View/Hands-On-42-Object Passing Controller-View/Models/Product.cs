﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Hands_On_42_Object_Passing_Controller_View.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;

    namespace LearnASPNETMVCWithRealApps.Models
    {
        public class Product
        {
            public string Id { get; set; }
            public string Name { get; set; }
            public string Photo { get; set; }
            public double Price { get; set; }
            public int Quantity { get; set; }
        }
    }
}