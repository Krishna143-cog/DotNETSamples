﻿using Hands_On_42_Object_Passing_Controller_View.Models.LearnASPNETMVCWithRealApps.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Hands_On_42_Object_Passing_Controller_View.Controllers
{
    public class DemoController : Controller
    {
        // GET: Demo
        public ActionResult Index()
        {
            Product product = new Product()
            {
                Id = "p01",
                Name = "Name 1",
                Photo = "k1.jpg",
                Price = 5.5,
                Quantity = 4
            };
            ViewBag.product = product;
            return View();
        }
    }
}